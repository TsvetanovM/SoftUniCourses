create
    definer = root@localhost procedure usp_transfer_money(IN from_account_id int, IN to_account_id int, IN amount decimal(19, 4))
BEGIN

	IF (amount > 0)
    AND ((SELECT id FROM accounts WHERE id = from_account_id) IS NOT NULL)
    AND ((SELECT id FROM accounts WHERE id = to_account_id) IS NOT NULL)
    THEN 
    START TRANSACTION;
    
		UPDATE accounts
        SET balance = balance - amount
        WHERE id = from_account_id;
        
        UPDATE accounts
        SET balance = balance + amount
        WHERE id = to_account_id;
        
		IF ((SELECT balance FROM accounts WHERE id = from_account_id) < 0)
        THEN ROLLBACK;
        ELSE COMMIT;
        
        END IF;
    
    END IF;
END;

