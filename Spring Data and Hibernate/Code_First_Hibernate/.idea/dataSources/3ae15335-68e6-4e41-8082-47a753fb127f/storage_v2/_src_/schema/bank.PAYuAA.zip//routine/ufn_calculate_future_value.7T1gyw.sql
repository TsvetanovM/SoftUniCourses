create
    definer = root@localhost function ufn_calculate_future_value(sum decimal(19, 4), yearly_interest_rate double,
                                                                 number_of_years int) returns decimal(19, 4)
BEGIN

	RETURN sum * (POW(1 + yearly_interest_rate, number_of_years));
    
END;

