create definer = root@localhost trigger accounts_after_balance_update
    after update
    on accounts
    for each row
BEGIN

	INSERT INTO `logs` (account_id, old_sum, new_sum)
	VALUES
    (OLD.id, OLD.balance, NEW.balance);    
    
END;

