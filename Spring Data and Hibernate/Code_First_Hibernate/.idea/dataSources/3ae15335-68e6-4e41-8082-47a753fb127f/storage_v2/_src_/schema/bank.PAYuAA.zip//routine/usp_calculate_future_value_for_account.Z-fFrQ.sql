create
    definer = root@localhost procedure usp_calculate_future_value_for_account(IN account_id int, IN inerest_rate decimal(19, 4))
BEGIN

		SELECT a.id AS account_id, first_name, last_name, balance AS current_balance, 
        ufn_calculate_future_value(a.balance, inerest_rate, 5) AS balance_in_5_years
        FROM accounts AS A
        JOIN account_holders AS ah ON account_holder_id = ah.id
        WHERE a.id = account_id;
        
END;

