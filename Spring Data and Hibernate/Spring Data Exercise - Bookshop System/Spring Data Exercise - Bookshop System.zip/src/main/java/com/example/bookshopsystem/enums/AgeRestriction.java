package com.example.bookshopsystem.enums;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
