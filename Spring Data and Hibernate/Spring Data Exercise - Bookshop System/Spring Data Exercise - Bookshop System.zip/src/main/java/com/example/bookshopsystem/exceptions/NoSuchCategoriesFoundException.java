package com.example.bookshopsystem.exceptions;

public class NoSuchCategoriesFoundException extends Throwable {
}
