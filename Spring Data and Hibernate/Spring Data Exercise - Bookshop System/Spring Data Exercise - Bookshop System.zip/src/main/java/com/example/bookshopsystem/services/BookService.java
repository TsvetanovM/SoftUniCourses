package com.example.bookshopsystem.services;

import java.io.IOException;

public interface BookService {
    void findBooksAfter2000_1();
    void seedBooks() throws IOException;
    void findAllBooksByAuthorNameOrderByReleaseDateDescTitleAsc(String firstName, String lastName);
}
