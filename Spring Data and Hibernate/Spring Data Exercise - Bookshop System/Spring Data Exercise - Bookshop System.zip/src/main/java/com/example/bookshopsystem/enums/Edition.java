package com.example.bookshopsystem.enums;

public enum Edition {
    NORMAL,
    PROMO,
    GOLD
}
