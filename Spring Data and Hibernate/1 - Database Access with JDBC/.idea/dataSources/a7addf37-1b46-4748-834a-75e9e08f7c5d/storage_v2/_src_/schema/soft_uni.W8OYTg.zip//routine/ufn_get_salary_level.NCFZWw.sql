create
    definer = root@localhost function ufn_get_salary_level(salary decimal(12, 2)) returns varchar(20)
BEGIN
	DECLARE result VARCHAR(20);
    CASE
		WHEN salary < 30000 THEN RETURN 'Low';
        WHEN salary BETWEEN 30000 AND 50000 THEN RETURN 'Average';
        ELSE RETURN 'High';
	END CASE;
END;

