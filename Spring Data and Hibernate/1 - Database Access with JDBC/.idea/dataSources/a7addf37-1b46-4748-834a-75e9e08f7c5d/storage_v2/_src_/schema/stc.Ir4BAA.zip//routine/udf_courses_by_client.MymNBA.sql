create
    definer = root@localhost function udf_courses_by_client(phone_num varchar(20)) returns int
BEGIN
	DECLARE result INT;
	SET result = (SELECT COUNT(co.id)
	FROM clients AS cl
    JOIN courses AS co ON cl.id = co.client_id
    WHERE cl.phone_number = phone_num
    GROUP BY co.client_id);
	IF result IS NOT NULL
    THEN 
    RETURN result;
    ELSE 
    RETURN 0;
    END IF;
    
END;

