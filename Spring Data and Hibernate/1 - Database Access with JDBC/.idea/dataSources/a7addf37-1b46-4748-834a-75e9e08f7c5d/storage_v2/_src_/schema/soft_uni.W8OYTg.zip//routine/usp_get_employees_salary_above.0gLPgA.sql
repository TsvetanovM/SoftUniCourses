create
    definer = root@localhost procedure usp_get_employees_salary_above(IN min_salary_to_show decimal(10, 4))
BEGIN 
	SELECT first_name, last_name
    FROM employees
    WHERE salary >= min_salary_to_show
    ORDER BY first_name, last_name, employee_id;
END;

