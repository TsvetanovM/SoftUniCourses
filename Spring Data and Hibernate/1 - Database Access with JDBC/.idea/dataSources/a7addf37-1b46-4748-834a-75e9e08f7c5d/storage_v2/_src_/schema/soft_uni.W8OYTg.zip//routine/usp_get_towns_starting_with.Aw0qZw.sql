create
    definer = root@localhost procedure usp_get_towns_starting_with(IN town_name_starts_with varchar(50))
BEGIN
	SELECT `name` AS town_name
    FROM towns
    WHERE LEFT(`name`, CHAR_LENGTH(town_name_starts_with)) = town_name_starts_with
    ORDER BY `name`;
END;

