create
    definer = root@localhost procedure usp_get_employee_by_salary_level(IN level_of_salary varchar(10))
BEGIN
	SELECT first_name, last_name
    FROM employees
	WHERE 
    (CASE 
		WHEN LOWER(level_of_salary) = 'low' THEN salary < 30000
        WHEN LOWER(level_of_salary) = 'average' THEN salary BETWEEN 30000 AND 50000
        ELSE salary > 50000
	END)
    ORDER BY first_name DESC, last_name DESC;
END;

