create definer = root@localhost trigger tr_new_log_added_notification_email
    after insert
    on logs
    for each row
BEGIN

	INSERT INTO notification_emails (recipient, subject, body)
    VALUES (NEW.log_id, CONCAT('Balance change for account: ', NEW.account_id), CONCAT_WS(' ', 'On date', CURRENT_TIMESTAMP, 'your balance was changed from', NEW.old_sum, 'to', NEW.new_sum));
    
END;

