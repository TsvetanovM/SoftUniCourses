create
    definer = root@localhost procedure usp_withdraw_money(IN account_id int, IN money_amount decimal(19, 4))
BEGIN

	START TRANSACTION;
    IF (SELECT balance FROM accounts WHERE id = account_id) >= money_amount
    AND money_amount > 0
    THEN 
    UPDATE accounts SET balance = balance - money_amount WHERE id = account_id;
    COMMIT;
    ELSE 
    ROLLBACK;
    END IF;
    
END;

