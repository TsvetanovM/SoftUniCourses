create
    definer = root@localhost procedure usp_get_holders_with_balance_higher_than(IN min_balance decimal(19, 4))
BEGIN
	
    SELECT first_name, last_name
    FROM account_holders AS ah
    JOIN accounts AS a ON a.account_holder_id = ah.id
    GROUP BY ah.id
    HAVING SUM(balance) > min_balance
    ORDER BY ah.id ASC;
    
END;

