package footballBetting.enums;

public enum Prediction {
    Home_Team_Win,
    Away_Team_Win,
    Draw,
}
