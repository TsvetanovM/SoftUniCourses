Здравейте!

Направил съм различен PersistenceUnit в persistence.xml файла за да е по-добре форматирано домашното.
Моля въведете username и password за вашия MySQL server във всеки от тях.