package softuni.jsonprocessing.productsShop.exceptions;

public class FileCouldNotBeSerialized extends Throwable {
}
