package com.example.football;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballApplicationTests {

    @Test
    void contextLoads() {
    }

}
