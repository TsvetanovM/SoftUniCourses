package onlineShop.models.products.components;

public class RandomAccessMemory extends BaseComponent{
    private static final double PERFORMANCE_MULTIPLIER = 1.2;

    public RandomAccessMemory(int id, String manufacturer, String model, double price, double overallPerformance, int generation) {
        super(id, manufacturer, model, price, overallPerformance, generation);
    }
}
