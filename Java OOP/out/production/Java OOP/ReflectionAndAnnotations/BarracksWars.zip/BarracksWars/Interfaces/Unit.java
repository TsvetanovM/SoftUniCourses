package ReflectionAndAnnotations.BarracksWars.Interfaces;

public interface Unit extends Destroyable, Attacker {
}
