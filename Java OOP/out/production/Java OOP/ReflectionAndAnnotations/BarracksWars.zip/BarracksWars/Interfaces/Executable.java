package ReflectionAndAnnotations.BarracksWars.Interfaces;

public interface Executable {

	String execute();

}
