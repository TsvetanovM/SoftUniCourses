package ReflectionAndAnnotations.BarracksWars.Interfaces;

public interface UnitFactory {

    Unit createUnit(String unitType);
}