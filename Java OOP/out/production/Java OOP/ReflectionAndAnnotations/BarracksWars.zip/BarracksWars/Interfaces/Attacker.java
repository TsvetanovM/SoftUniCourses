package ReflectionAndAnnotations.BarracksWars.Interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
