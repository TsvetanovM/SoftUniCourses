package ReflectionAndAnnotations.BarracksWars.Interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
