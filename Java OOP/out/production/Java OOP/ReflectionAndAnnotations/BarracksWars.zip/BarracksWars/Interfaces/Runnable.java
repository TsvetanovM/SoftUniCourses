package ReflectionAndAnnotations.BarracksWars.Interfaces;

public interface Runnable {
	void run();
}
